# Warsztat 3: Custom domain — Twój własny adres

> ⚠️ **Ten warsztat jest klikaniem w GUI — prowadzący prowadzi krok po kroku.**

## Cel
Dodać własną domenę do aplikacji na Vercel. Zamiast `random-name.vercel.app` → `twoj-agent.pl`.

## Krok po kroku

### 1. Kup domenę (opcjonalnie)
- Tani registrar: OVH.pl, nazwa.pl, Cloudflare Registrar
- Darmowa subdomena: jeśli masz już domenę (np. firma.pl) → dodaj agent.firma.pl
- Lub: użyj darmowej domeny od Vercel (name.vercel.app — customizable)

### 2. Dodaj domenę w Vercel
1. Vercel Dashboard → Twój projekt → Settings → Domains
2. Wpisz domenę: `twoj-agent.pl` (lub subdomenę)
3. Vercel pokaże rekordy DNS do dodania

### 3. Skonfiguruj DNS
1. Wejdź na panel swojego registrara (OVH, Cloudflare, nazwa.pl)
2. Dodaj rekord:
   - Typ: CNAME
   - Nazwa: `@` (lub `agent` dla subdomeny)
   - Wartość: `cname.vercel-dns.com`
3. Poczekaj 1-5 minut na propagację DNS

### 4. Weryfikacja
1. Vercel Dashboard → Domains → status: ✅ Valid Configuration
2. SSL/HTTPS: Vercel automatycznie generuje certyfikat
3. Otwórz: `https://twoj-agent.pl` → Twoja aplikacja!

## Test
1. Vercel Dashboard → Domains → domena widoczna z zielonym ✅
2. Otwórz URL w przeglądarce → Twoja apka ✅
3. HTTPS działa (kłódka w pasku adresu) ✅

## Dlaczego to jest ważne
`random-xyz.vercel.app` brzmi amatorsko. `twoj-agent.pl` brzmi profesjonalnie. Custom domain = marka = zaufanie.
