# Warsztat 3: Quick fix — napraw 1 bug z feedbacku na żywo

> 📋 **Skopiuj i wklej do AI assistanta:**
> *"[WKLEJ 1 BUG Z KARTY FEEDBACKU]. Napraw to."*

## Cel
Napraw JEDEN konkretny bug lub ulepsz JEDNĄ rzecz na podstawie feedbacku od kolegi/koleżanki.

## Jak to zrobić

### 1. Wybierz 1 rzecz z karty feedbacku
Przeczytaj kartę od partnera. Wybierz JEDNĄ rzecz:
- 🔴 Bug → napraw (najwyższy priorytet)
- 🟡 Ulepszenie → wdróż (np. brak przycisku "Kopiuj")
- 💡 Pomysł → zaimplementuj (np. "dodaj dark/light toggle")

### 2. Wklej do AI assistanta
Dosłownie wklej opis problemu:
- "Gdy odświeżam stronę, ostatnia rozmowa się nie ładuje. Napraw."
- "Dodaj przycisk 'Kopiuj odpowiedź' przy każdej wiadomości agenta."
- "Na telefonie layout się psuje — tekst wychodzi poza ekran. Napraw responsive."

### 3. Zweryfikuj fix
- Przetestuj czy działa
- Opcjonalnie: poproś partnera żeby też sprawdził

### 4. Deploy
```
git add .
git commit -m "Fix: [opis]"
git push
```

## Czas: 15 minut
To nie jest moment na wielkie zmiany. Jeden fix. Deploy. Gotowe.

## Dlaczego to jest ważne
Feedback bez action = marnowanie czasu. Feedback + natychmiastowy fix = kultura ciągłego ulepszania. W 15 minut Twój agent jest LEPSZY niż był godzinę temu — dzięki oczom innej osoby.
