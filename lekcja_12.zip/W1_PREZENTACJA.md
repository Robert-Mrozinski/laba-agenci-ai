# Warsztat 1: Prezentacja Twojego agenta (5 min)

> ⚠️ **Ten warsztat jest INNY — to PREZENTACJA na żywo, nie kodowanie.**

## Cel
Każdy student prezentuje swojego agenta grupie. 5 minut: co zbudował, demo na żywo, co jest wyjątkowe.

## Format prezentacji (5 minut)

### Minuta 1: Wprowadzenie
- Jak się nazywa Twój agent? (np. "Atlas AI", "Nexus", "Mira")
- Do czego służy? 1 zdanie. (np. "Asystent wiedzy firmowej z bazą wiedzy i automatycznymi briefingami")
- Pokaż landing page

### Minuty 2-3: Demo na żywo
- Pokaż NAJFAJNIEJSZĄ funkcję
- Np. "Pytam o cennik → agent odpowiada z mojego dokumentu + cytuje źródło"
- Np. "Wklejam 5 maili → agent sortuje w 3 sekundy"
- Np. "Rano otwieram /briefings → agent przygotował podsumowanie dnia"
- UŻYWAJ PRAWDZIWYCH DANYCH — nie testowych

### Minuta 4: Własny scenariusz (z L08 W4)
- Pokaż scenariusz który SAM wymyśliłeś
- "Zbudowałem [co] bo w mojej pracy [problem] i to oszczędza mi [ile czasu]"

### Minuta 5: Podsumowanie
- "Z czego jestem dumny" (1 rzecz)
- "Co chciałbym poprawić" (1 rzecz)
- "Co dalej" (1 pomysł na przyszłość)

## Zasady
- Każdy prezentuje — nikt nie jest pominięty
- Demo NA ŻYWO (nie screenshoty) — pokaż działającego agenta
- Jeśli coś nie zadziała na żywo — to nie porażka, to lekcja (powiedz co miało zadziałać)
- Grupa daje feedback po każdej prezentacji (W2)

## Kolejność
Prowadzący ustala kolejność. Ochotnicy najpierw. 
Grupa ~15 osób × 5 min = ~75 min. 
Z przerwami i feedbackem: ~90-100 min.
